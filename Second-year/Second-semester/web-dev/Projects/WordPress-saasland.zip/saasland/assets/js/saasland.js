import $ from 'jquery';
import './components/custom-wp';
import './components/love';
import './components/saasland-quick-view';
import './components/mega-menu';