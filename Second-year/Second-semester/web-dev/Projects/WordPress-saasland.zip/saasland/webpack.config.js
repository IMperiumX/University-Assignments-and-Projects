const path = require('path');
module.exports = (env, argv) => {
  const isDevelopment = argv.mode !== 'production';
  console.log(isDevelopment)
  return {
    entry: {
      saasland:'./assets/js/saasland.js',
    },
    
    output: {
      path: path.resolve(__dirname, 'assets/js'),
      filename: 'saasland.min.js'
    },
    externals: {
      jquery: 'jQuery',
    },
  
  }
}
